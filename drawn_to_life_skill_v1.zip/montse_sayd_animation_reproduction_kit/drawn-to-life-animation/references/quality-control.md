# Quality-control checklist

## Frame defects

- duplicated or fused feet;
- extra hands, fingers, faces, people, or garment pieces;
- malformed head or abruptly altered likeness;
- missing suit contour, dress hem, sleeve, shoe, or hand contact;
- opaque rectangles, horizontal bars, checkerboard, labels, or borders;
- pencil marks unrelated to form;
- background tone inconsistent with adjacent frames.

## Temporal defects

- person height or width changes abruptly;
- head center jumps while the torso remains still;
- one faulty scale persists through later frames;
- foot contact slides without corresponding body motion;
- transition into or out of a repaired range pops;
- both people appear in old and new positions;
- cadence resembles a crossfade slideshow instead of sequential drawings.

## Review method

1. Watch at 12 fps and record the first visible disturbance.
2. Step through at least two frames before and after it.
3. Compare crown, chin, shoulders, waist, hem, shoes, and joined hands.
4. Repair the smallest defensible range.
5. Rewatch the range plus its boundaries at 12 fps.
6. Check the final export over the real page background on desktop and mobile.

Do not approve scale using thumbnails alone. Contact sheets reveal gross inconsistencies; playback reveals motion discomfort.
