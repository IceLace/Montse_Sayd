# Artistic rotoscope workflow

## Goal

Transform a photographic performance into individual pencil drawings that remain recognizable and temporally coherent. This is a redraw workflow, not a global video filter.

## Establish references

Approve one representative frame before processing the full sequence. Lock facial likeness, hairstyle, clothing construction, pencil character, composition, and relative height of both people. Keep a small reference set containing the approved still, a clear face reference for each person, and frames with especially accurate clothing.

## Generate sequentially

For each new frame, provide the original photographic frame, the approved style reference, and the immediately preceding approved drawing. Ask for a faithful redraw of the current pose, not a reinterpretation.

Prompt skeleton:

> Redraw this exact frame as a hand-made graphite/sepia pencil animation cel. Preserve the identity, pose, body proportions, clothing construction, camera framing, and relative scale established by the approved reference. Use confident anatomical contours plus secondary construction strokes, fold-following hatching, selective erased marks, and slight frame-specific line variation. Keep the background uniformly light and empty. Do not duplicate limbs or people, invent floor lines, crop the bodies, change the camera, beautify faces, or alter body width.

Avoid “random sketch noise”; it encourages floating scratches unrelated to the drawing.

## Correct locally

When one region fails, prefer a local redraw or regeneration of that frame. Preserve everything already correct. Useful targeted corrections include matching a head to the next frame, removing a duplicate foot, retaining height while restoring torso width, matching both people’s scale to neighbors, and normalizing paper color without changing line art.

## Review motion

Inspect at native 12 fps and also frame-step. Verify transitions at the entrance and exit of every corrected range. Attractive individual drawings can still produce unpleasant motion when head centers, widths, or ground contacts jump.
