---
name: drawn-to-life-animation
description: Convert a short couple or dance video into a stable frame-by-frame pencil animation for a paper-themed website, including visual QA, scale correction, transparent sepia export, poster creation, and mobile integration. Use when recreating the Montse & Sayd “Drawn to Life” workflow or a closely related rotoscope animation; do not treat a photographic video as if a simple filter can replace per-frame drawing and review.
---

# Drawn to Life Animation

Recreate the visual standard established for the Montse & Sayd closing animation: recognizable people, believable pencil construction, consistent anatomy and scale, stable motion, and transparent integration over an existing paper page.

## Determine the input stage

- If the input is a photographic video, perform the artistic rotoscope stage before technical export. Read [references/artistic-workflow.md](references/artistic-workflow.md).
- If the input is already a light-background pencil animation, proceed to normalization and transparency with `scripts/build_transparent_animation.py`.
- If corrected PNG frames are supplied, preserve them as the source of truth and assemble them without regenerating good frames.

Never imply that luminance extraction or a pencil filter alone reproduces the approved look. The quality came from individual drawings plus temporal review.

## Non-negotiable visual invariants

- Preserve source aspect ratio at every transformation. Never force people into a square canvas.
- Default final canvas: 540×810, exact 2:3, square pixels.
- Default cadence: 12 fps. Do not interpolate invented frames unless explicitly requested.
- Compare each frame with both neighbors. A plausible still can still cause a visible jump.
- Keep identity, head size, shoulder width, torso width, dress silhouette, feet, and contact hands coherent.
- Pencil noise must follow anatomy, folds, hair, gesture, and erased construction; do not add unrelated random scratches.
- Avoid duplicated limbs, fused feet, ghost people, horizontal bars, opaque rectangles, checkerboards, QA labels, and background color flashes.
- Do not discard an approved frame merely to make the sequence stylistically uniform. Repair only the faulty region or frame when possible.

## Working sequence

1. Inspect the entire source and record fps, dimensions, duration, and orientation.
2. Extract at 12 fps. Assign permanent frame numbers; never renumber after review begins.
3. Generate or draw frames using stable character references and the preceding approved frame.
4. Review in short overlapping ranges and create numbered contact sheets with `scripts/make_contact_sheet.py`.
5. Flag temporal problems using [references/quality-control.md](references/quality-control.md).
6. Correct only flagged frames, then review boundaries immediately before and after each repaired range.
7. Assemble a normal MP4 preview first. Confirm scale and movement before transparency.
8. Run `scripts/build_transparent_animation.py` on the approved light-background sequence or preview.
9. Composite the transparent result over the actual page background for QA. Do not stretch a square texture to approximate the page.
10. Deliver the transparent animated WebP, static poster, MP4 QA preview, numbered contact sheet, processing configuration, and source/corrected frames when preservation matters.

## Technical export

Example matching the Montse & Sayd final settings:

```bash
python3 scripts/build_transparent_animation.py \
  approved-sketch.mp4 output \
  --fps 12 \
  --canvas-width 540 \
  --canvas-height 810 \
  --drawing-width 420 \
  --offset-y 25 \
  --mask-top 66 \
  --line-color 73,55,43
```

The `--mask-top` option is only for known QA labels in a fixed top region. Set it to `0` for clean sources. Never use it to hide anatomy.

## Website integration

- Use the animated WebP as an `<img>` mounted only when its stage begins.
- Preserve its natural 2:3 ratio with `object-fit: contain`; do not place it in a square wrapper.
- Use the poster for load states and `prefers-reduced-motion`.
- If the WebP loops at codec level, enforce a single visible play by mounting it at start and removing it after the known duration.
- Do not apply CSS chroma key, blend modes, masks, crop, or per-frame transforms to repair an incorrectly exported asset.

## Stop and request review

Pause before full-sequence regeneration when identity, clothing, framing, or drawing style has not been approved on a representative still and a short motion sample. After approval, continue autonomously but retain frame numbers and report every repaired range.
