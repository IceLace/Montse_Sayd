#!/usr/bin/env python3
"""Create a transparent sepia WebP and poster from a light-background sketch video."""

from __future__ import annotations

import argparse
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image


def run(command: list[str]) -> None:
    subprocess.run(command, check=True)


def parse_color(value: str) -> tuple[int, int, int]:
    parts = tuple(int(part.strip()) for part in value.split(','))
    if len(parts) != 3 or any(part < 0 or part > 255 for part in parts):
        raise argparse.ArgumentTypeError('Use R,G,B with values from 0 through 255')
    return parts


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('input_video', type=Path)
    parser.add_argument('output_directory', type=Path)
    parser.add_argument('--fps', type=int, default=12)
    parser.add_argument('--canvas-width', type=int, default=540)
    parser.add_argument('--canvas-height', type=int, default=810)
    parser.add_argument('--drawing-width', type=int, default=420)
    parser.add_argument('--offset-y', type=int, default=25)
    parser.add_argument('--mask-top', type=int, default=0)
    parser.add_argument('--line-color', type=parse_color, default=(73, 55, 43))
    parser.add_argument('--white-point', type=float, default=235)
    parser.add_argument('--alpha-range', type=float, default=68)
    parser.add_argument('--alpha-power', type=float, default=0.9)
    parser.add_argument('--max-alpha', type=int, default=235)
    args = parser.parse_args()

    if not args.input_video.is_file():
        parser.error(f'Input not found: {args.input_video}')
    if min(args.canvas_width, args.canvas_height, args.drawing_width, args.fps) <= 0:
        parser.error('Dimensions and fps must be positive')

    args.output_directory.mkdir(parents=True, exist_ok=True)
    frames_output = args.output_directory / 'transparent_frames'
    frames_output.mkdir(exist_ok=True)

    with tempfile.TemporaryDirectory(prefix='drawn-to-life-') as temporary:
        extracted = Path(temporary)
        run([
            'ffmpeg', '-y', '-v', 'error', '-i', str(args.input_video),
            '-vf', f'fps={args.fps},scale={args.drawing_width}:-2:flags=lanczos',
            str(extracted / 'frame_%04d.png'),
        ])

        source_frames = sorted(extracted.glob('frame_*.png'))
        if not source_frames:
            raise RuntimeError('FFmpeg extracted no frames')

        for index, source_path in enumerate(source_frames, start=1):
            frame = Image.open(source_path).convert('RGB')
            array = np.asarray(frame, dtype=np.float32)
            luminance = array[..., 0] * 0.299 + array[..., 1] * 0.587 + array[..., 2] * 0.114
            alpha = np.clip((args.white_point - luminance) / args.alpha_range, 0, 1)
            alpha = np.power(alpha, args.alpha_power)
            if args.mask_top:
                alpha[: min(args.mask_top, frame.height), :] = 0

            rgba = np.empty((frame.height, frame.width, 4), dtype=np.uint8)
            rgba[..., :3] = args.line_color
            rgba[..., 3] = np.uint8(alpha * args.max_alpha)
            drawing = Image.fromarray(rgba, 'RGBA')

            canvas = Image.new('RGBA', (args.canvas_width, args.canvas_height), (0, 0, 0, 0))
            offset_x = (args.canvas_width - frame.width) // 2
            if offset_x < 0 or args.offset_y + frame.height > args.canvas_height:
                raise ValueError('Scaled drawing does not fit the requested canvas')
            canvas.alpha_composite(drawing, (offset_x, args.offset_y))
            canvas.save(frames_output / f'frame_{index:04d}.png')

    animation = args.output_directory / 'drawn-to-life-transparent.webp'
    run([
        'ffmpeg', '-y', '-v', 'error', '-framerate', str(args.fps),
        '-i', str(frames_output / 'frame_%04d.png'),
        '-c:v', 'libwebp_anim', '-quality', '82', '-compression_level', '5',
        '-loop', '1', '-pix_fmt', 'yuva420p', str(animation),
    ])

    first_frame = Image.open(frames_output / 'frame_0001.png').convert('RGBA')
    first_frame.save(args.output_directory / 'drawn-to-life-poster.webp', 'WEBP', quality=90, method=6)
    print(f'Created {len(source_frames)} frames at {args.fps} fps')
    print(animation)


if __name__ == '__main__':
    main()
