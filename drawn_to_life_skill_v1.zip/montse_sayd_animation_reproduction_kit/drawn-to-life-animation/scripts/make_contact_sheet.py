#!/usr/bin/env python3
"""Build a numbered contact sheet from a PNG frame directory."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('frame_directory', type=Path)
    parser.add_argument('output_image', type=Path)
    parser.add_argument('--columns', type=int, default=5)
    parser.add_argument('--thumbnail-width', type=int, default=240)
    parser.add_argument('--start', type=int, default=1)
    parser.add_argument('--end', type=int)
    args = parser.parse_args()

    frames = sorted(args.frame_directory.glob('frame_*.png'))
    selected = frames[args.start - 1 : args.end]
    if not selected:
        parser.error('No matching PNG frames found in the requested range')

    first = Image.open(selected[0])
    thumbnail_height = round(args.thumbnail_width * first.height / first.width)
    label_height = 30
    rows = math.ceil(len(selected) / args.columns)
    sheet = Image.new('RGB', (args.columns * args.thumbnail_width, rows * (thumbnail_height + label_height)), 'white')
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()

    for slot, path in enumerate(selected):
        frame_number = args.start + slot
        image = Image.open(path).convert('RGBA')
        paper = Image.new('RGBA', image.size, (246, 240, 226, 255))
        paper.alpha_composite(image)
        thumb = paper.convert('RGB').resize((args.thumbnail_width, thumbnail_height), Image.Resampling.LANCZOS)
        x = (slot % args.columns) * args.thumbnail_width
        y = (slot // args.columns) * (thumbnail_height + label_height)
        sheet.paste(thumb, (x, y))
        draw.text((x + 8, y + thumbnail_height + 8), f'FRAME {frame_number}', fill=(35, 29, 25), font=font)

    args.output_image.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(args.output_image, quality=92)
    print(args.output_image)


if __name__ == '__main__':
    main()
