# Cómo reutilizar el flujo Drawn to Life

La carpeta reutilizable es `drawn-to-life-animation`.

## En una futura sesión

1. Adjunta este ZIP o la carpeta `drawn-to-life-animation`.
2. Adjunta el video original y las fotografías claras de referencia de las personas.
3. Escribe:

   > Usa `$drawn-to-life-animation` para convertir este video en una animación de dibujo a lápiz como la de Montse y Sayd. Primero genera una muestra representativa y un fragmento corto para aprobar identidad, estilo y escala; después procesa el resto a 12 fps.

4. Si la sesión no reconoce automáticamente el skill, indica expresamente:

   > Lee completamente `drawn-to-life-animation/SKILL.md` y sigue sus referencias y scripts.

## Qué conserva

- El flujo de dibujo individual y revisión temporal.
- Los parámetros finales de 12 fps y lienzo 540×810 en proporción 2:3.
- Los criterios para corregir escalas, cabezas, pies, duplicidades y saltos.
- La conversión a líneas sepia con fondo transparente.
- La creación del WebP animado, poster y hojas de contacto numeradas.

La imagen `assets/montse-sayd-quality-reference.jpg` sirve como referencia visual de consistencia, no como fuente para regenerar identidades.
